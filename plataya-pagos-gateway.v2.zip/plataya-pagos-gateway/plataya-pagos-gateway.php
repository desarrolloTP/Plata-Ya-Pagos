<?php
/**
 * Plugin Name: Plata Ya Pagos Gateway
 * Plugin URI: https://pagos.plataya.com/
 * Description:
 * Version: 1.0
 * Author: Mariano Labollita
 * Author URI: http://www.bimit.com.ar
 */

// Exit if accessed directly.
if (!defined('ABSPATH')) {
	exit ;
}

// Make sure WooCommerce is active
if ( ! in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) {
	return;
}

/**
 * Se agrega el gateway como pasarela de pagos
 * 
 * @since 1.0.0
 * @param array $gateways all available WC gateways
 * @return array $gateways all WC gateways + offline gateway
 */
function wc_plataya_pagos_add_to_gateways( $gateways ) {
	$gateways[] = 'WC_Gateway_PlataYa_Pagos';
	return $gateways;
}
add_filter( 'woocommerce_payment_gateways', 'wc_plataya_pagos_add_to_gateways' );
/**
 * Adds plugin page links
 * 
 * @since 1.0.0
 * @param array $links all plugin links
 * @return array $links all plugin links + our custom links (i.e., "Settings")
 */
function wc_plataya_pagos_gateway_plugin_links( $links ) {
	$plugin_links = array(
		'<a href="' . admin_url( 'admin.php?page=wc-settings&tab=checkout&section=plataya_pagos_gateway' ) . '">' . __( 'Configure', 'wc-gateway-plataya_pagos' ) . '</a>'
	);
	return array_merge( $plugin_links, $links );
}
add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), 'wc_plataya_pagos_gateway_plugin_links' );
/**
 * Offline Payment Gateway
 *
 * Provides an Offline Payment Gateway; mainly for testing purposes.
 * We load it later to ensure WC is loaded first since we're extending it.
 *
 * @class 		WC_Gateway_Plataya_Pagos
 * @extends		WC_Payment_Gateway
 * @version		1.0.0
 * @package		WooCommerce/Classes/Payment
 * @author 		SkyVerge
 */
add_action( 'plugins_loaded', 'wc_plataya_pagos_gateway_init', 11 );
function wc_plataya_pagos_gateway_init() {
	class WC_Gateway_PlataYa_Pagos extends WC_Payment_Gateway {

		private $url_creacion_orden;
		private $url_guardado_orden;
		private $url_checkout_plataya_pagos;
		private $url_obtener_orden;

		/**
		 * Constructor de la pasarela de pagos Plata Ya Pagos
		 */
		public function __construct() {

			$this->id                 = 'plataya_pagos_gateway';
			$this->icon               = apply_filters('woocommerce_plataya_pagos_gateway_icon', plugins_url('plataya-pagos-gateway/assets/images/plataya-pagos.png', plugin_dir_path(__FILE__)));
			$this->has_fields         = false;
			$this->method_title       = 'Plata Ya Pagos Gateway';
			$this->method_description = 'Permite pagos utilizando la plataforma Plata Ya Pagos.';
			
			// inicializo las funciones del plugin
			$this->init_form_fields();
			$this->init_settings();
			
			// Definino variables del usuaroi
			$this->title        = 'Plata Ya Pagos';
			$this->description  = 'Plata Ya Pagos es un medio de pago innovador para financiar tus compras en internet, sin necesidad de una tarjeta de crédito o débito. Tu crédito online deberás abonarlo mensualmente en los lugares habilitados.';
			$this->instructions = 'Plata Ya Pagos es un medio de pago innovador para financiar tus compras en internet, sin necesidad de una tarjeta de crédito o débito. Tu crédito online deberás abonarlo mensualmente en los lugares habilitados.';

			// Evalúo si se encuentra en testing o producción
			if (strtolower($this->get_option('checkout_credential_production')) == 'si') {

				$this->url_creacion_orden = 'http://servicios.plataya.com.ar/api/Operation/empty';
				$this->url_guardado_orden = 'http://servicios.plataya.com.ar/api/Operation/Save';
				$this->url_obtener_orden = 'http://servicios.plataya.com.ar/api/Operation/';
				$this->url_checkout_plataya_pagos = 'https://pagos.plataya.com.ar/checkoutapi/';
			} else {
				$this->url_creacion_orden = 'http://test-servicios.plataya.com.ar/api/Operation/empty';
				$this->url_guardado_orden = 'http://test-servicios.plataya.com.ar/api/Operation/Save';
				$this->url_obtener_orden = 'http://test-servicios.plataya.com.ar/api/Operation/';
				$this->url_checkout_plataya_pagos = 'https://pagos.plataya.com.ar/checkoutapi-test/';
			}
			
			// Configuro los ACTIONS
			add_action( 'woocommerce_update_options_payment_gateways_' . $this->id, array( $this, 'process_admin_options' ) );
			add_action( 'woocommerce_thankyou_' . $this->id, array( $this, 'thankyou_page' ) );

			// Configuro Plata Ya Pagos IPN
			add_action( 'woocommerce_api_wc_gateway_plataya_pagos', array( $this, 'webhook' ) );
		}
		

		/**
		 * 	Inicialización del formulario de configuración de la pasarela de pagos
		 * 
		 */
		function init_form_fields() {
			global $woocommerce;

			$this->form_fields = apply_filters( 'wc_plataya_pagos_gateway_form_fields', array(
		  
				'checkout_credential_production' => array(
					'title' => 'Producción',
					'type' => 'select',
					'description' => 'Elija SI cuando esté listo para realizar ventas. Seleccione NO para activar el modo de pruebas.',
					'default' => ($this->get_option('production') == 'SI') ? 'SI' : 'NO',
					'options' => array(
						'no' => 'NO',
						'yes' => 'SI'
					)
					),

				'commerce_id' => array(
					'title'       => 'Código de Comercio',
					'type'        => 'text',
					'description' => 'Es el código de comercio asociado a Plata Ya Pagos.',
					'desc_tip'    => true,
				),
				
				'commerce_contact' => array(
					'title'       => 'Email de contacto',
					'type'        => 'text',
					'description' => 'Email de contacto del comercio.',
					'default'     => '',
					'desc_tip'    => true,
				),
				
				'commerce_logo' => array(
					'title'       => 'Logo de comercio',
					'type'        => 'text',
					'description' => 'Logo del comercio para mostrarlo en la pasarela de pagos de Plata Ya Pagos.',
					'default'     => '',
					'desc_tip'    => true,
				),

				'commerce_url_ok' => array(
					'title'       => 'URL de éxito',
					'type'        => 'text',
					'description' => 'URL de éxito de la operación.',
					'default'     => 'https://ecommerce.plataya.com.ar/wc-api/wc_gateway_plataya_pagos',
					'desc_tip'    => true,
				),

				'commerce_url_error' => array(
					'title'       => 'URL de pago rechazado ',
					'type'        => 'text',
					'description' => 'URL de pago rechazado.',
					'default'     => 'https://ecommerce.plataya.com.ar/wc-api/wc_gateway_plataya_pagos',
					'desc_tip'    => true,
				),

				'commerce_url_pending' => array(
					'title'       => 'URL de pago pendiente ',
					'type'        => 'text',
					'description' => 'URL de pago pendiente .',
					'default'     => 'https://ecommerce.plataya.com.ar/wc-api/wc_gateway_plataya_pagos',
					'desc_tip'    => true,
				),

				'commerce_gateway_discount' => array(
					'title'       => 'Descuentos pasarela',
					'type'        => 'text',
					'description' => 'Descuentos al utilizar la pasarela. Ejemplo: 10 equivale a 10%',
					'default'     => '0',
					'desc_tip'    => true,
				),

				'commerce_gateway_charge' => array(
					'title'       => 'Recargo pasarela',
					'type'        => 'text',
					'description' => 'Recargos al utilizar la pasarela. Ejemplo: 10 equivale a 10%',
					'default'     => '0',
					'desc_tip'    => true,
				),

				'commerce_extra_1' => array(
					'title'       => 'Parámetros extra pasarela 1',
					'type'        => 'text',
					'description' => 'Parámetros extra pasarela 1',
					'default'     => '',
					'desc_tip'    => true,
				),

				'commerce_extra_2' => array(
					'title'       => 'Parámetros extra pasarela 2',
					'type'        => 'text',
					'description' => 'Parámetros extra pasarela 2',
					'default'     => '',
					'desc_tip'    => true,
				)

			) );

		}

		/**
		 * Devuelve la URL de templates
		 * 
		 */
		public static function get_templates_path() {
			return plugin_dir_path( __FILE__ ) . 'templates/';
		}
	
		/**
		 * Muestra la descripción de la pasarela en el checkout
		 */
		public function payment_fields() {

			echo wpautop(wp_kses_post($this->description));
		}
		
		/**
		 *  El plugin no tiene campos que validar
		 */
		public function validate_fields() {
			$error = false;
			
			return !$error;
		}
	
	
		/**
		 * Envía al usuario a la página de agradecimiento
		 */
		public function thankyou_page() {
			if ( $this->instructions ) {
				echo wpautop( wptexturize( $this->instructions ) );
			}
		}
	
		/**
		 * Procesa la orden y la envía a Plata Ya Pagos
		 *
		 * @param int $order_id
		 * @return array
		 */
		public function process_payment( $order_id ) {

			// Obtengo la orden
			$order = wc_get_order( $order_id );
			
			// La marco como pendiente de pago con Plata Ya Pagos
			$order->update_status( 'on-hold', 'Esperando Pago con Plata Ya Pagos');
		
			
			$articulos = array();
			$id_item = 1;
			foreach($order->get_items() as $item) {
				array_push($articulos, 
									array('id_item' => $id_item++,
										  'family' => '1',
										  'type' => '1',
										  'seller_code' => $item->get_product_id(),
										  'quantity' => $item->get_quantity(),
										  'amount' => array(
															'description' => $item->get_name(), 
															'amount' => $item->get_total()
															)
										  )
							);
			}
			
			/** Armo el Array con los datos de la orden */
			$args = json_decode($response['body'], true);
			
			$args['shop']['id'] = $this->get_option('commerce_id');
			$args['shop']['contact_info'] = $this->get_option('commerce_contact');
			$args['shop']['logo_url'] = $this->get_option('commerce_logo');

			$args['customer']['dni'] = '';
			$args['customer']['gender'] = '';
			$args['customer']['first_name'] = $order->get_billing_first_name();
			$args['customer']['last_name'] = $order->get_billing_last_name();
			$args['customer']['mail'] = $order->get_billing_email();
			$args['customer']['phone_number'] = $order->get_billing_phone();

			$args['total_amount']['amount'] = $order->get_total();
			$args['global_discount']['amount'] = $this->get_option('commerce_gateway_discount');
			$args['global_charge']['amount'] = $this->get_option('commerce_gateway_charge');

			$args['behaviour']['urls']['success'] = $this->get_option('commerce_url_ok');
			$args['behaviour']['urls']['pending'] = $this->get_option('commerce_url_pending');
			$args['behaviour']['urls']['failure'] = $this->get_option('commerce_url_error');

			$args['callback']['transaction_id'] = $order_id;

			$args['items'] = $articulos;

			$response = wp_remote_post( $this->url_guardado_orden, 
										array('headers' => array('Content-Type' => 'application/json'), 
											  'body' => json_encode($args))
									 );
			$response_arr = json_decode($response['body'], true);

			/** redirecciono a la página de checkout de Plata Ya Pagos */
			return array(
				'result' 	=> 'success',
				'redirect'	=> $this->url_checkout_plataya_pagos . '?transaction_id=' . $response_arr['id']
			);
		}

		/**
		 * Hook que se activa cuando regresa de la operación de venta
		 */
		public function webhook() {
			$_POST['params'] = str_replace("\\", "", $_POST['params']); 
			$response = json_decode($_POST['params']);

			$response = wp_remote_get( $this->url_obtener_orden . $response->transaccion_id , array());
			$response_arr = json_decode($response['body'], true);
			$order_id = $response_arr['callback']['transaction_id'];
			$order = wc_get_order( $order_id ); // Obtengo la orden

			// Evalúo el resultado de la operación
			if (strtolower($response_arr['result']['description']) == 'success' || strtolower($response_arr['result']['description']) == 'pending') { // salió todo OK
				
				$order->payment_complete(); // La marco como completa
				$order->reduce_order_stock(); // Reduzco stock
				WC()->cart->empty_cart(); // Vacío carrito
			
				update_option('webhook_debug', $response); 
				
				wp_redirect($order->get_checkout_order_received_url()); // Redirecciono a Thank you Page
			} else if (strtolower($response->status) == 'failure' || strtolower($response->status) == 'in process') { // La operación falló
				// Algo falló 
				$order->update_status('failed', 'Plata Ya Pagos: El Pago fue rechazado.'); // Seteo el estado de la operación

				update_option('webhook_debug', $response);

				wp_redirect($order->get_checkout_order_received_url()); // Redirecciono a página de error
			}
		}
	
  }
}